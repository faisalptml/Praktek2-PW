<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>PRAKTEK 6</title>

</head>
<body>

<div id="container">
	<h1>SEMANGAT BELAJAR!</h1>

	<div id="body">
		<p>Jangan Lupa Berdoa Sebelum Belajar</p>

	</div>
</div>

</body>
</html>
